$(function () {

    datatableInit = () =>{
        $('#tb_kategori').DataTable();
    }

     

    $('#testt').on('click',function () {
        alert('dsfsdf');
    })
})