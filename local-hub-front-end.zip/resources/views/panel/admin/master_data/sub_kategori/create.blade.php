<form>
  
    <div class="form-group">
        <label id="kategori_">Pilih Kategori</label>
        <select name="" id="kategori_" class="form-control">
            
        </select>
    </div>

  <div class="form-group">
    <label for="nama">Nama</label>
    <input type="text" class="form-control" id="nama" aria-describedby="emailHelp" placeholder="Nama">
  </div>

  <div class="form-group">
    <label for="nama">Gambar</label>
    <input type="date" class="form-control" id="nama" aria-describedby="emailHelp" placeholder="Enter email">
  </div>
    
    <div class="form-group">
        <label id="status_">Status</label>
        <select name="" id="status_" class="form-control">
            <option disabled selected>-- Pilih --</option>
            <option value="Aktif">Aktif</option>
            <option value="Tidak Aktif">Tidak Aktif</option>
        </select>
    </div>
</form>