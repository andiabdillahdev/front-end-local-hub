<form>
<div class="form-group">
    <label for="nama">Nama</label>
    <input type="text" class="form-control" id="nama" aria-describedby="emailHelp" placeholder="Nama">
  </div>

</form>