<form>
<div class="form-group">
    <label for="nama">Nama</label>
    <input type="text" class="form-control" id="nama" aria-describedby="emailHelp" placeholder="Nama">
</div>

<div class="form-group">
    <label for="nama">Provinsi</label>
    <select name="" class="form-control" id=""></select>
</div>

<div class="form-group">
    <label for="nama">Kabupaten</label>
    <select name="" class="form-control" id=""></select>
</div>

<div class="form-group">
    <label for="nama">Kecamatan</label>
    <select name="" class="form-control" id=""></select>
</div>

<div class="form-group">
    <label for="nama">Kelurahan</label>
    <select name="" class="form-control" id=""></select>
</div>
    
    <div class="form-group">
        <label id="status_">Status</label>
        <select name="" id="status_" class="form-control">
            <option disabled selected>-- Pilih --</option>
            <option value="Aktif">Aktif</option>
            <option value="Tidak Aktif">Tidak Aktif</option>
        </select>
    </div>
</form><?php /**PATH C:\laragon\www\local-hub-front-end\resources\views/panel/admin/master_data/kategori_transport/create.blade.php ENDPATH**/ ?>