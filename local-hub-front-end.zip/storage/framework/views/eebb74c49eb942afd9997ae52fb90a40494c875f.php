<form>
<div class="form-group">
    <label for="nama">Nama</label>
    <input type="text" class="form-control" id="nama" aria-describedby="emailHelp" placeholder="Nama">
  </div>

</form><?php /**PATH C:\laragon\www\local-hub-front-end\resources\views/panel/admin/master_data/tag/create.blade.php ENDPATH**/ ?>